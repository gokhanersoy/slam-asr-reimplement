#!/usr/bin/env python3
"""Generate Colab notebook for Turkish Common Voice SLAM-ASR."""

import json
import os

notebook = {
 "cells": [
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# SLAM-ASR: Türkçe Mozilla Common Voice Konuşma Tanıma\n",
    "### Mozilla Data Collective (MDC) & Modern Türkçe Çok Modlu ASR\n",
    "\n",
    "> **Referans Makale:** *An Embarrassingly Simple Approach for LLM with Strong ASR Capacity* ([arXiv:2402.08846](https://arxiv.org/abs/2402.08846))\n",
    "> **Veri Seti:** Mozilla Common Voice (Turkish) via [Mozilla Data Collective](https://mozilladatacollective.com)\n",
    "> **MDC Dataset ID:** `cmu5wkah500c2o10719lem8m8`\n",
    "\n",
    "Bu notebook, Google Colab (ücretsiz T4 veya ücretli A100/L4) üzerinde **Mozilla Common Voice Türkçe** veri seti ile SLAM-ASR modelini kurmak, eğitmek ve test etmek için hazırlanmıştır.\n",
    "\n",
    "---\n",
    "### Temel Mimarisi:\n",
    "* **Akustik Kodlayıcı:** `openai/whisper-small` - **Dondurulmuş (Frozen)**\n",
    "* **Dil Modeli (LLM):** `Qwen/Qwen2.5-7B-Instruct` - **Dondurulmuş (Frozen)**\n",
    "* **Projektör:** $k=5$ Ardışık Çerçeve Birleştirme (50 Hz $\\to$ 10 Hz) + Tek Lineer Katman - **Eğitilen Tek Bileşen** (~%0.6 parametre)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 1. GPU ve Donanım Kontrolü\n",
    "Colab oturumunuzun GPU hızlandırıcıya bağlı olduğunu doğrulayın (Menü: `Runtime` -> `Change runtime type` -> `T4 GPU` veya `A100 GPU`)."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "metadata": {},
   "outputs": [],
   "source": [
    "# GPU kullanılabilirliğini kontrol edin\n",
    "!nvidia-smi\n",
    "\n",
    "import torch\n",
    "print(f\"[*] PyTorch Versiyonu: {torch.__version__}\")\n",
    "print(f\"[*] CUDA Kullanılabilir mi?: {torch.cuda.is_available()}\")\n",
    "if torch.cuda.is_available():\n",
    "    print(f\"[*] Aktif GPU: {torch.cuda.get_device_name(0)}\")\n",
    "    print(f\"[*] VRAM: {round(torch.cuda.get_device_properties(0).total_memory / (1024**3), 2)} GB\")\n"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 2. Depo Dosyalarını Hazırlama ve Bağımlılıkları Yükleme\n",
    "GitHub reposunu çekin veya çalışma dizinine geçin ve gerekli paketleri yükleyin."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "metadata": {},
   "outputs": [],
   "source": [
    "import os\n",
    "\n",
    "# Eğer doğrudan GitHub'dan klonlayacaksanız:\n",
    "if not os.path.exists(\"tr\") and not os.path.exists(\"slam_asr\"):\n",
    "    !git clone https://github.com/gokhanersoy/slam-asr-reimplement.git\n",
    "    %cd slam-asr-reimplement/tr/cv\n",
    "elif os.path.exists(\"tr/cv\"):\n",
    "    %cd tr/cv\n",
    "\n",
    "# Bağımlılıkları yükleyin\n",
    "!pip install -q -r requirements.txt\n",
    "!pip install -q soundfile torchaudio bitsandbytes accelerate datacollective mutagen\n"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 3. Kod Dosyalarının Doğrulanması ve Birim Testler\n",
    "Birim testleri koşturarak modüllerin ve Common Voice veri işleme mantığının hazır olduğunu doğrulayın."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "metadata": {},
   "outputs": [],
   "source": [
    "!python run_tests.py\n"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 4. Hızlı Doğrulama: Sentetik Türkçe Veri ile Test Eğitimi (30 Saniye)\n",
    "Büyük veri setini indirmeden önce tüm boru hattının sorunsuz çalıştığını sentetik verimizle test edin."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "metadata": {},
   "outputs": [],
   "source": [
    "# 1. Sentetik Türkçe test verisini üretin\n",
    "!python scripts/create_toy_turkish_dataset.py\n",
    "\n",
    "# 2. Hızlı doğrulama eğitimini koşturun (50 adım)\n",
    "!python train.py --config config/train_toy_debug_turkish.yaml\n"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 5. Mozilla Common Voice (Türkçe) Veri Seti İndirme ve Hazırlığı\n",
    "Colab Secrets (Sol paneldeki anahtar simgesi 🔑) üzerinden `MDC_API_KEY` anahtarınız okunur ve Mozilla Data Collective API'si aracılığıyla dataset (`cmu5wkah500c2o10719lem8m8`) otomatik olarak indirilip hazırlanır."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "metadata": {},
   "outputs": [],
   "source": [
    "from google.colab import userdata\n",
    "import os\n",
    "\n",
    "# Colab Secrets'tan MDC_API_KEY anahtarını alın\n",
    "try:\n",
    "    mdc_api_key = userdata.get('MDC_API_KEY')\n",
    "    print(\"[*] MDC_API_KEY anahtari Colab Secrets uzerinden basariyla alindi.\")\n",
    "except Exception:\n",
    "    mdc_api_key = input(\"Lutfen Mozilla Data Collective API anahtarinizi (MDC_API_KEY) girin: \")\n",
    "\n",
    "# Mozilla Common Voice Türkçe veri setini indirin ve hazırlayın\n",
    "!python scripts/prepare_common_voice.py \\\n",
    "    --download \\\n",
    "    --api_key \"{mdc_api_key}\" \\\n",
    "    --output_dir data/cv\n"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 6. Donanıma Göre Otomatik Optimize Olan SLAM-ASR Türkçe Eğitimi\n",
    "Donanım profilleyicimiz (`device_utils`) GPU'nuza göre en verimli hassasiyeti (bfloat16/float16), kuantizasyonu (4-bit NF4) ve batch boyutunu otomatik olarak belirler."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "metadata": {},
   "outputs": [],
   "source": [
    "# Donanıma göre otomatik optimize edilen Türkçe SLAM-ASR eğitimi\n",
    "!python train.py --config config/hardware_adaptive_turkish.yaml\n"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 7. Model Değerlendirmesi (Türkçe WER ve CER Hesaplama)\n",
    "Eğitilen modelin Common Voice test seti üzerindeki performansını ölçün. Türkçe büyük/küçük harf (`İ -> i`, `I -> ı`) ve noktalama normalizasyonu otomatik uygulanır."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "metadata": {},
   "outputs": [],
   "source": [
    "!python evaluate.py \\\n",
    "    --config config/hardware_adaptive_turkish.yaml \\\n",
    "    --checkpoint outputs/slam_asr_cv_turkish_adaptive/best_checkpoint \\\n",
    "    --manifest data/cv/test.jsonl \\\n",
    "    --language tr \\\n",
    "    --beam_size 4\n"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 8. İnteraktif Çıkarım (Test Sesini Dinleme ve Transkribe Etme)\n",
    "Test setindeki bir Common Voice ses kaydını dinleyin ve modelinizin konuşmayı nasıl yazıya döktüğünü canlı olarak görün."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "metadata": {},
   "outputs": [],
   "source": [
    "import json\n",
    "import os\n",
    "import IPython.display as ipd\n",
    "\n",
    "# Test setinden ilk örneği bulun\n",
    "sample_audio = None\n",
    "sample_text = \"\"\n",
    "\n",
    "manifest_file = \"data/cv/test.jsonl\" if os.path.exists(\"data/cv/test.jsonl\") else \"data/sample_val_tr.jsonl\"\n",
    "if os.path.exists(manifest_file):\n",
    "    with open(manifest_file, \"r\", encoding=\"utf-8\") as f:\n",
    "        first_line = f.readline()\n",
    "        if first_line:\n",
    "            data = json.loads(first_line)\n",
    "            sample_audio = data.get(\"audio_filepath\")\n",
    "            sample_text = data.get(\"text\", \"\")\n",
    "\n",
    "if sample_audio and os.path.exists(sample_audio):\n",
    "    print(f\"[*] Seçilen Ses: {sample_audio}\")\n",
    "    print(f\"[*] Gerçek Metin (Ground Truth): {sample_text}\\n\")\n",
    "    display(ipd.Audio(sample_audio))\n",
    "    \n",
    "    !python inference.py \\\n",
    "        --audio \"{sample_audio}\" \\\n",
    "        --config config/hardware_adaptive_turkish.yaml \\\n",
    "        --checkpoint outputs/slam_asr_cv_turkish_adaptive/best_checkpoint/projector.pt \\\n",
    "        --prompt \"Konuşmayı metne dönüştürün.\"\n",
    "else:\n",
    "    print(\"[!] Test ses dosyası bulunamadı. Lütfen ses dosyasının yolunu elle belirtin.\")\n"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 9. Zaman Damgalı Google Drive Yedeklemesi\n",
    "Eğitilen ağırlıkları (`best_checkpoint`), test sonuçlarını (`eval_results.jsonl`), manifestoları ve konfigürasyonu Google Drive'a tarih/saat damgalı olarak kalıcı yedekleyin."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "metadata": {},
   "outputs": [],
   "source": [
    "# 9. Adım: Tüm Model Ağırlıklarını, Manifestoları ve Test Sonuçlarını Drive'a Yedekleme\n",
    "import os\n",
    "from datetime import datetime\n",
    "from google.colab import drive\n",
    "\n",
    "# 1. Google Drive'ı bağlayın\n",
    "drive.mount(\"/content/drive\")\n",
    "\n",
    "# 2. Zaman damgalı hedef klasörü belirleyin\n",
    "timestamp = datetime.now().strftime(\"%Y%m%d_%H%M%S\")\n",
    "drive_target_dir = f\"/content/drive/MyDrive/checkpoints/slam_asr_cv_turkish_{timestamp}\"\n",
    "os.makedirs(drive_target_dir, exist_ok=True)\n",
    "\n",
    "# 3. Model Ağırlıklarını Kopyalayın\n",
    "!cp -r outputs/slam_asr_cv_turkish_adaptive/best_checkpoint \"{drive_target_dir}/\"\n",
    "!cp -r outputs/slam_asr_cv_turkish_adaptive/final_checkpoint \"{drive_target_dir}/\"\n",
    "\n",
    "# 4. (Varsa) Değerlendirme Çıktısını Kopyalayın\n",
    "if os.path.exists(\"eval_results.jsonl\"):\n",
    "    !cp eval_results.jsonl \"{drive_target_dir}/\"\n",
    "\n",
    "# 5. Veri Manifestolarını Kopyalayın (train/val/test jsonl)\n",
    "if os.path.exists(\"data/cv\"):\n",
    "    os.makedirs(f\"{drive_target_dir}/manifests\", exist_ok=True)\n",
    "    !cp data/cv/*.jsonl \"{drive_target_dir}/manifests/\"\n",
    "\n",
    "# 6. Kullanılan Config Dosyasını Kopyalayın\n",
    "!cp config/hardware_adaptive_turkish.yaml \"{drive_target_dir}/\"\n",
    "\n",
    "print(\"\\n\" + \"=\" * 65)\n",
    "print(f\"[*] Tam Yedekleme Başarıyla Tamamlandı!\")\n",
    "print(f\"[*] Hedef Dizin: {drive_target_dir}\")\n",
    "print(\"    • best_checkpoint & final_checkpoint\")\n",
    "print(\"    • eval_results.jsonl (Test tahminleri ve WER analizi)\")\n",
    "print(\"    • train/val/test manifestoları\")\n",
    "print(\"    • hardware_adaptive_turkish.yaml konfigürasyonu\")\n",
    "print(\"=\" * 65)\n"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 10. Modeli Belleğe Yükle ve Canlı Mikrofon Kaydı ile Konuşmayı Metne Dönüştür\n",
    "Model GPU belleğine bir kere yüklenir ve hazır bekler. Ardından tarayıcınızdan mikrofona Türkçe konuşursunuz ve model konuşmanızı 1 saniye içinde yazıya döker."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "metadata": {},
   "outputs": [],
   "source": [
    "# 10. Adım: Modeli Belleğe Yükle ve Mikrofon ile Canlı Konuşmayı Metne Dönüştür\n",
    "import os\n",
    "import glob\n",
    "import subprocess\n",
    "import yaml\n",
    "from base64 import b64decode\n",
    "import torch\n",
    "import IPython.display as ipd\n",
    "from google.colab import output\n",
    "\n",
    "from slam_asr.models.slam_model import SLAM_ASR, SLAMASRConfig\n",
    "from slam_asr.data.audio_processor import AudioProcessor\n",
    "from slam_asr.utils.device_utils import resolve_auto_hyperparameters\n",
    "\n",
    "# 1. Drive'ı Bağla ve En Güncel Checkpoint'i Bul\n",
    "if not os.path.exists(\"/content/drive/MyDrive\"):\n",
    "    from google.colab import drive\n",
    "    drive.mount(\"/content/drive\")\n",
    "\n",
    "checkpoint_candidates = sorted(glob.glob(\"/content/drive/MyDrive/checkpoints/slam_asr_cv_turkish_*/best_checkpoint/projector.pt\"))\n",
    "if not checkpoint_candidates:\n",
    "    checkpoint_candidates = sorted(glob.glob(\"/content/drive/MyDrive/checkpoints/slam_asr_turkish_*/best_checkpoint/projector.pt\"))\n",
    "\n",
    "if checkpoint_candidates:\n",
    "    best_ckpt = checkpoint_candidates[-1]\n",
    "elif os.path.exists(\"outputs/slam_asr_cv_turkish_adaptive/best_checkpoint/projector.pt\"):\n",
    "    best_ckpt = \"outputs/slam_asr_cv_turkish_adaptive/best_checkpoint/projector.pt\"\n",
    "else:\n",
    "    raise FileNotFoundError(\"Hiçbir best_checkpoint/projector.pt dosyası bulunamadı!\")\n",
    "\n",
    "# 2. Modeli GPU'ya Yükle (Zaten Yüklüyse Tekrar Yüklemez!)\n",
    "if \"loaded_slam_model\" not in globals():\n",
    "    print(f\"[*] Model checkpoint'i kullanılıyor:\\n    {best_ckpt}\\n\")\n",
    "    print(\"[*] 1/3: Model GPU VRAM'ine yükleniyor... Lütfen bekleyin...\")\n",
    "    \n",
    "    cfg = yaml.safe_load(open(\"config/hardware_adaptive_turkish.yaml\"))\n",
    "    model_cfg = cfg.get(\"model\", {})\n",
    "    data_cfg = cfg.get(\"data\", {})\n",
    "    model_cfg, data_cfg, _ = resolve_auto_hyperparameters(model_cfg, data_cfg, {})\n",
    "    \n",
    "    device = torch.device(\"cuda\" if torch.cuda.is_available() else \"cpu\")\n",
    "    model_config = SLAMASRConfig(**model_cfg)\n",
    "    \n",
    "    model = SLAM_ASR(config=model_config)\n",
    "    if not getattr(model_config, \"load_in_4bit\", False) and not getattr(model_config, \"load_in_8bit\", False):\n",
    "        model = model.to(device)\n",
    "    else:\n",
    "        model.speech_encoder = model.speech_encoder.to(device)\n",
    "        model.projector = model.projector.to(device)\n",
    "        \n",
    "    state_dict = torch.load(best_ckpt, map_location=device)\n",
    "    model.projector.load_state_dict(state_dict)\n",
    "    model.eval()\n",
    "    \n",
    "    audio_proc = AudioProcessor(\n",
    "        sampling_rate=data_cfg.get(\"sampling_rate\", 16000),\n",
    "        is_whisper=data_cfg.get(\"is_whisper\", True),\n",
    "        whisper_mel_bins=data_cfg.get(\"whisper_mel_bins\", 80),\n",
    "    )\n",
    "    \n",
    "    loaded_slam_model = model\n",
    "    loaded_audio_proc = audio_proc\n",
    "    loaded_device = device\n",
    "    loaded_model_config = model_config\n",
    "    print(\"[*] 2/3: Model başarıyla VRAM'e yüklendi ve hazır bekliyor! 🚀\\n\")\n",
    "else:\n",
    "    print(\"[*] Model zaten VRAM'de hazır bekliyor (Yeniden yükleme yapılmadı). 🚀\\n\")\n",
    "\n",
    "# 3. Model Hazır Olduktan Sonra Mikrofon Butonunu Göster\n",
    "RECORD_JS = \"\"\"\n",
    "const sleep = time => new Promise(resolve => setTimeout(resolve, time));\n",
    "const b2text = blob => new Promise(resolve => {\n",
    "  const reader = new FileReader();\n",
    "  reader.onloadend = e => resolve(e.target.result);\n",
    "  reader.readAsDataURL(blob);\n",
    "});\n",
    "var recordAudio = () => new Promise(async (resolve, reject) => {\n",
    "  try {\n",
    "    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });\n",
    "    const recorder = new MediaRecorder(stream);\n",
    "    const chunks = [];\n",
    "    recorder.ondataavailable = e => chunks.push(e.data);\n",
    "\n",
    "    const container = document.createElement(\"div\");\n",
    "    container.style.cssText = \"padding: 12px; margin: 10px 0; background: #1e1e2e; border-radius: 8px; color: white; font-family: sans-serif; display: inline-block;\";\n",
    "\n",
    "    const btn = document.createElement(\"button\");\n",
    "    btn.innerHTML = \"🔴 Kaydı Başlat (Konuşmaya Başlayın)\";\n",
    "    btn.style.cssText = \"padding: 12px 24px; font-size: 16px; font-weight: bold; background: #e74c3c; color: white; border: none; border-radius: 6px; cursor: pointer; transition: 0.3s; box-shadow: 0 4px 6px rgba(0,0,0,0.3);\";\n",
    "    container.appendChild(btn);\n",
    "    document.body.appendChild(container);\n",
    "\n",
    "    let isRecording = false;\n",
    "\n",
    "    btn.onclick = () => {\n",
    "      if (!isRecording) {\n",
    "        recorder.start();\n",
    "        isRecording = true;\n",
    "        btn.innerHTML = \"⏹️ Kaydı Bitir (Sonucu Gör)\";\n",
    "        btn.style.background = \"#27ae60\";\n",
    "      } else {\n",
    "        recorder.stop();\n",
    "        btn.innerHTML = \"⏳ Model transkribe ediyor...\";\n",
    "        btn.disabled = true;\n",
    "        btn.style.background = \"#7f8c8d\";\n",
    "      }\n",
    "    };\n",
    "\n",
    "    recorder.onstop = async () => {\n",
    "      const blob = new Blob(chunks, { type: \"audio/webm\" });\n",
    "      const base64Text = await b2text(blob);\n",
    "      container.remove();\n",
    "      resolve(base64Text);\n",
    "    };\n",
    "  } catch (err) {\n",
    "    reject(err);\n",
    "  }\n",
    "});\n",
    "recordAudio();\n",
    "\"\"\"\n",
    "\n",
    "print(\"[*] 3/3: Mikrofon hazır. Konuşmak için aşağıdaki butona basın:\")\n",
    "audio_data = output.eval_js(RECORD_JS)\n",
    "\n",
    "# 4. Sesi 16 kHz Mono WAV Formatına Dönüştür\n",
    "webm_file = \"live_temp.webm\"\n",
    "wav_file = \"live_mic_recording.wav\"\n",
    "\n",
    "with open(webm_file, \"wb\") as f:\n",
    "    f.write(b64decode(audio_data.split(\",\")[1]))\n",
    "\n",
    "subprocess.run([\n",
    "    \"ffmpeg\", \"-y\", \"-i\", webm_file,\n",
    "    \"-ar\", \"16000\", \"-ac\", \"1\",\n",
    "    wav_file\n",
    "], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)\n",
    "\n",
    "print(\"\\n[*] Kaydettiğiniz Ses:\")\n",
    "display(ipd.Audio(wav_file))\n",
    "\n",
    "# 5. Bellekteki Model ile Anında Çıkarım\n",
    "speech_tensor = loaded_audio_proc.process(wav_file).unsqueeze(0).to(loaded_device)\n",
    "use_amp = (loaded_model_config.torch_dtype in (\"float16\", \"bfloat16\")) and loaded_device.type == \"cuda\"\n",
    "amp_dtype = torch.bfloat16 if loaded_model_config.torch_dtype == \"bfloat16\" else torch.float16\n",
    "\n",
    "with torch.no_grad():\n",
    "    if use_amp:\n",
    "        with torch.cuda.amp.autocast(dtype=amp_dtype):\n",
    "            transcription = loaded_slam_model.generate(\n",
    "                speech_inputs=speech_tensor,\n",
    "                prompts=[\"Konuşmayı metne dönüştürün.\"],\n",
    "                num_beams=4,\n",
    "            )[0]\n",
    "    else:\n",
    "        transcription = loaded_slam_model.generate(\n",
    "            speech_inputs=speech_tensor,\n",
    "            prompts=[\"Konuşmayı metne dönüştürün.\"],\n",
    "            num_beams=4,\n",
    "        )[0]\n",
    "\n",
    "print(\"\\n\" + \"=\" * 55)\n",
    "print(f\"🗣️  Sizin Konuşmanız: {transcription}\")\n",
    "print(\"=\" * 55)\n"
   ]
  }
 ],
 "metadata": {
  "accelerator": "GPU",
  "colab": {
   "gpuType": "T4",
   "provenance": []
  },
  "language_info": {
   "name": "python"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 0
}

out_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "slam_asr_colab_tr_cv.ipynb")
with open(out_path, "w", encoding="utf-8") as f:
    json.dump(notebook, f, indent=1, ensure_ascii=False)

print(f"Generated {out_path} successfully!")
